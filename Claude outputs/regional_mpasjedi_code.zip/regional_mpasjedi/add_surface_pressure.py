#!/usr/bin/env python3
"""
Add surface_pressure to an MPAS mpasout file, if it isn't already there.

zgrid (vertical grid interface heights) is read from the invariant/mesh
file; theta, pressure (pressure_base + pressure_p, or pressure if that's
what the file has instead), and qv are read from the mpasout file itself.
surface_pressure is diagnosed via hydrostatic extrapolation of the lowest
model level down to the surface (the hypsometric equation, using the
virtual temperature so moist air is accounted for), then written back
into the mpasout file as:

    float surface_pressure(Time, nCells) ;
            surface_pressure:units = "Pa" ;
            surface_pressure:long_name = "Surface pressure" ;

Usage
-----
    python3 add_surface_pressure.py invariant.nc mpasout.nc [mpasout2.nc ...]
    python3 add_surface_pressure.py invariant.nc mpasout*.nc --force

By default, a mpasout file that already has surface_pressure is left
alone (reported, not touched). Pass --force to recompute it anyway and
compare the recalculated values against what's already in the file
(max/mean absolute and relative differences) -- this does NOT overwrite
the existing values, it's a diagnostic comparison only. Use --overwrite
(together with --force) if you actually want the recomputed values
written back.

Note: adding a brand-new variable to a file that already has data written
in it (the normal r+ edit here) forces a one-time nc_redef()/nc_enddef()
header-resize -- if the file's reserved header space is too small for the
extra variable, netCDF shifts the whole existing data section down to
make room. That's an unavoidable, one-time cost of appending a variable
after the fact (not a bug in this script), and can take a while on a
large production mpasout file -- it is NOT something that compounds if
you only add this one variable once.

Performance notes
------------------
- Only the LOWEST model level of theta/qv/pressure is ever read (that's
  all the hydrostatic extrapolation needs) -- the read is a hyperslab
  selection at the netCDF layer, not a full-field read followed by a
  slice, so cost does not scale with nVertLevels.
- Multiple mpasout files are independent of each other, so pass
  --workers N to process N of them concurrently (separate processes) --
  this is usually the biggest win when updating many ensemble
  members/cycle times at once, since it overlaps each file's disk I/O
  and (for --overwrite on files missing the variable) redef cost.
"""
from __future__ import annotations

import argparse
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
import netCDF4 as nc

# ── hydrostatic-extrapolation constants -- match the MPAS model's own
#    framework constants (src/framework/mpas_constants.F in
#    MPAS-Dev/MPAS-Model), and the same values used elsewhere in this
#    project's diffusion-filter / blending tools (mpas_core/constants.py) ──
GRAVITY = 9.80616              # m s^-2, MPAS mpas_constants.F 'gravity'
RD      = 287.0                # J kg^-1 K^-1, dry-air gas constant, MPAS 'rgas'
RV      = 461.6                # J kg^-1 K^-1, water-vapor gas constant, MPAS 'rv'
EPS     = RD / RV              # ~0.622, dry/moist gas-constant ratio
P0      = 100_000.0            # Pa, MPAS 'p0'
CP      = 3.5 * RD             # J kg^-1 K^-1, MPAS 'cp' (=1004.5)
RD_CP   = RD / CP              # = 2/7 ~ 0.285714, MPAS 'rgas/cp' (kappa)


def theta_to_temperature(theta: np.ndarray, pressure: np.ndarray) -> np.ndarray:
    return theta * (pressure / P0) ** RD_CP


def compute_surface_pressure(
    p1: np.ndarray,       # (Time, nCells) -- pressure at the LOWEST mass level
    z_sfc: np.ndarray,    # (nCells,) -- terrain height, zgrid[:, 0]
    z1: np.ndarray,       # (nCells,) -- lowest mass-level midpoint height
    theta1: np.ndarray,   # (Time, nCells) -- potential temperature at the lowest level
    qv1: np.ndarray,      # (Time, nCells) -- water-vapor mixing ratio (kg/kg) at the lowest level
) -> np.ndarray:
    """
    Hydrostatically extrapolate the lowest model (mass) level's pressure
    down to the surface:

        P_sfc = P1 * exp( g * (z1 - z_sfc) / (Rd * Tv1) )

    where Tv1 is the VIRTUAL temperature at the lowest level
    (Tv = T*(qv+eps)/(eps*(1+qv)), the exact mixing-ratio form -- moist
    air is less dense than dry air at the same (T, P), so using plain T
    would overstate the extrapolated surface pressure).

    Takes lowest-level-only inputs (not full 3-D fields) on purpose: the
    caller reads just that one level as a netCDF hyperslab, so this whole
    diagnostic costs O(nCells), not O(nCells * nVertLevels).
    """
    dz = (z1 - z_sfc)[None, :]                       # (1, nCells), broadcasts over Time

    T1  = theta_to_temperature(theta1, p1)
    Tv1 = T1 * (qv1 + EPS) / (EPS * (1.0 + qv1))

    return p1 * np.exp(GRAVITY * dz / (RD * Tv1))


def load_zgrid(invariant_file: str) -> np.ndarray:
    """Read only the two lowest zgrid interfaces (terrain + first level
    top) -- that's all compute_surface_pressure needs, regardless of how
    many vertical levels the mesh actually has."""
    with nc.Dataset(invariant_file) as inv:
        if "zgrid" not in inv.variables:
            raise KeyError(f"zgrid not found in invariant file: {invariant_file}")
        return np.asarray(inv.variables["zgrid"][:, :2], dtype=np.float64)


def read_pressure_level0(ds: "nc.Dataset") -> np.ndarray:
    """Read only the lowest mass level of pressure, as a netCDF hyperslab
    (ds.variables[...][:, :, 0]) -- this does NOT read the full 3-D field
    first, so cost is independent of nVertLevels."""
    if "pressure" in ds.variables:
        return np.asarray(ds.variables["pressure"][:, :, 0], dtype=np.float64)
    for req in ("pressure_base", "pressure_p"):
        if req not in ds.variables:
            raise KeyError(
                "mpasout file has neither 'pressure' nor both "
                "'pressure_base'/'pressure_p' -- can't build full pressure."
            )
    return (np.asarray(ds.variables["pressure_base"][:, :, 0], dtype=np.float64)
            + np.asarray(ds.variables["pressure_p"][:, :, 0], dtype=np.float64))


def add_surface_pressure(
    mpasout_file: str,
    zgrid: np.ndarray,
    force: bool = False,
    overwrite: bool = False,
) -> None:
    with nc.Dataset(mpasout_file, "r+") as ds:
        already_present = "surface_pressure" in ds.variables

        if already_present and not force:
            print(f"[skip] {mpasout_file}: surface_pressure already present "
                  f"(pass --force to recompute)")
            return

        for req in ("theta", "qv"):
            if req not in ds.variables:
                raise KeyError(f"required variable '{req}' not found in {mpasout_file}")

        nCells = ds.dimensions["nCells"].size
        if zgrid.shape[0] != nCells:
            raise ValueError(
                f"{mpasout_file}: zgrid has {zgrid.shape[0]} cells but this "
                f"file has nCells={nCells} -- wrong invariant file for this mesh?"
            )

        # Lowest-level-only hyperslab reads -- avoids pulling all
        # nVertLevels off disk when only level 0 is ever used.
        theta1 = np.asarray(ds.variables["theta"][:, :, 0], dtype=np.float64)
        qv1    = np.asarray(ds.variables["qv"][:, :, 0], dtype=np.float64)
        p1     = read_pressure_level0(ds)
        z_sfc  = zgrid[:, 0]
        z1     = 0.5 * (zgrid[:, 0] + zgrid[:, 1])

        surface_pressure = compute_surface_pressure(p1, z_sfc, z1, theta1, qv1)

        # already present + --force, but NOT --overwrite: just report how
        # the recalculated values compare to what's already in the file,
        # and leave the file untouched.
        if already_present and not overwrite:
            existing = np.asarray(ds.variables["surface_pressure"][:], dtype=np.float64)
            diff = np.abs(surface_pressure - existing)
            denom = max(np.max(np.abs(existing)), 1e-30)
            max_abs = diff.max()
            mean_abs = diff.mean()
            max_rel = max_abs / denom
            print(f"[compare] {mpasout_file}: recalculated vs existing surface_pressure  "
                  f"max_abs_diff={max_abs:.3f} Pa  mean_abs_diff={mean_abs:.3f} Pa  "
                  f"max_rel_diff={max_rel:.3e}  (file NOT modified -- pass --overwrite to write)")
            return

        if already_present:
            v = ds.variables["surface_pressure"]
        else:
            v = ds.createVariable("surface_pressure", "f4", ("Time", "nCells"))
            v.units = "Pa"
            v.long_name = "Surface pressure"

        v[:] = surface_pressure.astype(np.float32)
        print(f"[done] {mpasout_file}: wrote surface_pressure  "
              f"shape={surface_pressure.shape}  "
              f"range=[{surface_pressure.min():.1f}, {surface_pressure.max():.1f}] Pa")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Diagnose and write surface_pressure into MPAS mpasout file(s)."
    )
    parser.add_argument("invariant_file", help="MPAS invariant/mesh file (source of zgrid)")
    parser.add_argument("mpasout_files", nargs="+", help="One or more mpasout files to update in place")
    parser.add_argument("--force", action="store_true",
                         help="Recompute surface_pressure even if already present. By "
                              "itself, this only compares the recalculated values against "
                              "what's already in the file (no write); combine with "
                              "--overwrite to actually replace them.")
    parser.add_argument("--overwrite", action="store_true",
                         help="Together with --force, write the recomputed surface_pressure "
                              "over the existing values (has no effect without --force).")
    parser.add_argument("-j", "--workers", type=int, default=1,
                         help="Process this many mpasout files concurrently (separate "
                              "processes; each file is independent). Default 1 = sequential. "
                              "Only helps when multiple mpasout_files are given.")
    args = parser.parse_args()

    zgrid = load_zgrid(args.invariant_file)

    failures = []
    if args.workers > 1 and len(args.mpasout_files) > 1:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            future_to_path = {
                pool.submit(add_surface_pressure, path, zgrid, args.force, args.overwrite): path
                for path in args.mpasout_files
            }
            for future in as_completed(future_to_path):
                path = future_to_path[future]
                try:
                    future.result()
                except Exception as exc:
                    print(f"[error] {path}: {exc}", file=sys.stderr)
                    failures.append(path)
    else:
        for path in args.mpasout_files:
            try:
                add_surface_pressure(path, zgrid, force=args.force, overwrite=args.overwrite)
            except Exception as exc:
                print(f"[error] {path}: {exc}", file=sys.stderr)
                failures.append(path)

    if failures:
        print(f"\n{len(failures)}/{len(args.mpasout_files)} file(s) failed: {failures}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
